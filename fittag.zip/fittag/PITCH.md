# FitTag — Pitch Pack

*The truth layer for secondhand fit. Keep this open when you present.*

*Companion assets: `deck.html` (slides + speaker cues) · `print/` (calibration kit) · live app at `http://127.0.0.1:8000`.*

---

## 0. One breath (say this first, every time)
> **"Online, you can't try clothes on — and secondhand is worse, because every item is one-of-a-kind with no size data. FitTag fixes that: lay a garment on our marker mat, take one photo, and we measure it to the centimetre with error bars. We're the only ones who can tell a buyer whether a specific vintage piece will actually fit."**

If you have ten seconds, that's the whole company.

---

## 1. The problem
- Returns in fashion run ~25–40%, and **fit is the #1 reason**.
- New retail has tools for this. **Secondhand has nothing** — because a one-off vintage item has no return history, no size chart, no SKU.
- "Size M" on a 1998 jacket is meaningless. Buyers guess. Sellers get returns. The platform eats the cost.

## 2. The wedge — why nobody else can do this *(this is the heart of the pitch)*
Every fit tool that works depends on data a one-off item structurally lacks:
- **Zara "What's My Size", True Fit, Fit Analytics** → need population return data / purchase history **per SKU**. Impossible for n = 1.
- **Google Doppl & generative try-on** → produce a plausible *image* that is **size-blind**. A hands-on review found Doppl literally **shrinks the garment to match your photo**. It shows the look, not the fit.

> **"Google shows you what it looks like but shrinks the clothes to fit your photo. Zara needs a million returns first. Secondhand has neither. We measure the actual garment — the only ones who can tell you the truth."**

> **"We don't need the data everyone else needs. We need the garment and one photo."**

## 3. How it works (architecture in two sentences)
- **Two layers.** A **TRUTH layer** (measured fit — defensible, the product) and a **VISUAL layer** (generative try-on — explicitly illustrative, never load-bearing).
- **Geometry measures; the AI only names.** ArUco markers + homography rectify the photo to a true top-down metric plane; silhouette geometry extracts the measurements; a vision model is used *only* to classify the garment type.

> **"The model never touches a number. Geometry does the measuring; the AI only names what it's looking at. Zero hallucinated centimetres."**

## 4. The number (technical-axis proof)
- Built a **validation harness**: engine output vs ground-truth measurements → mean absolute error.
- **Current result: MAE 0.14 cm across 30 measurements, 100% within tolerance** (on our controlled validation set).
- Honest framing out loud: *"That's our validation set; in the wild we quote ±1–1.5 cm, and the harness is built to re-run the moment we have real tape-measured photos."* Saying this **builds** credibility — it shows you know the difference.

## 5. Feature talking points (every one is built + tested)
1. **Multi-marker mat + homography.** Measures over *all* corner markers — no extrapolation. **Provably more rigorous than the published `mkurc1/climbingcrux_model`**, which uses one marker + bounding-box centres. *(You can say: "I went and checked the prior art — the standard approach uses a single marker and extrapolates; ours doesn't, and that's why our error is sub-centimetre.")*
2. **Measure a garment you own — from a photo.** Upload your favourite tee; it becomes your fit target. *"Does this listing fit like the one I already love?"*
3. **Size translation.** "Measures like a ~M / ~33" waist · UK 16" — for people who know their size but not their centimetres. Always caveated (vintage runs small).
4. **Fit confidence.** Propagates the measurement tolerance into the verdict: *"likely ideal, possibly snug"* near a boundary. Honest uncertainty = trust.
5. **Fit-feedback flywheel** *(theme 5 — the clever one)*. Buyers report how it actually fit. Each report nudges the thresholds **and** accumulates a proprietary **measurements → real-fit-outcome dataset across body types**.
   > **"Every 'it ran tight' makes the next prediction better. That's the data moat Zara has for new retail and nobody has for resale — and it compounds."**
6. **Fit-based search** *(theme 5 — the marketplace feature)*. Because every listing is measured, the catalog ranks by *your* fit.
   > **"You can finally search a marketplace by your own body. No resale platform can do that today."**
7. **Markerless option (experimental).** No mat? Use any A4 sheet or card as the scale reference. Lower friction, wider tolerance.
8. **Capture guidance.** Flags glare / poor light / missing markers / garment off the mat *before* the bad measurement happens.
9. **Generative try-on (visual layer).** Wired to FASHN / Gemini, always **labelled illustrative** — fixes Doppl's failure by pairing the look with the *measured* fit.

## 6. The 90-second live demo (click-by-click)
1. **Upload a flat-lay** (or hit *Run a sample*) → measurements appear with ± error bars on the rectified overlay, plus a "measures like ~M" badge. *"One photo. Real centimetres. The AI only named the t-shirt."*
2. **Drag the body sliders** → per-zone verdicts update live; point at a *"likely ideal, possibly snug"* chip → *"it even tells you when it's near a boundary."*
3. **Scroll to "Items that actually fit you"** → it's already ranked to those sliders. *"Search by your own fit — nobody has this."*
4. **Hit "Spot on / Ran tighter"** → *"that's the flywheel; this is how it gets smarter and how the data moat builds."*
5. Land on the wedge line from §2.

## 7. Read the room (judge calibration)
- **Alex Nikityuk (Fleek, Head of AI)** → lead with **rigour**: geometry-not-guessing, the homography, MAE 0.14 cm, "more rigorous than the published approach." He'll respect that you refused to let the model emit numbers.
- **Abhi Arora & Sanket Agarwal (Fleek founders)** → lead with **seller friction + returns**: one photo per listing, consistent measurements, fewer fit returns, a measurement layer their catalog can standardise on.
- **Olivia Moore (a16z)** → lead with the **moat + two-sided SaaS**: the feedback dataset compounds, fit-based search is a platform primitive, and it's defensible because the data is structurally unavailable to incumbents.

## 8. Self-framing (your unfair advantage — say it)
> *"I've shipped ArUco-based measurement before — a climbing-route optimiser that scales pixels to centimetres off fiducials. And the Vinted scraper feeding the catalog is my own (JeansFinder). FitTag is those two things pointed at a real market."*

## 9. The hard questions — answers ready
- **"Can't a seller just measure it with a tape?"**
  > *"Yes — and that's the right instinct. But will they, consistently, across forty listings, in a format a buyer trusts and can search? No. We're not claiming it's impossible by hand — we remove the tax, standardise it, and turn it into a data layer the marketplace can build on. Automation, not impossibility."* **(Never claim impossibility — concede the manual case and win on volume + consistency + the buyer/search layer.)**
- **"Is the AI making up the measurements?"** → *"No. Geometry measures; the model only classifies the garment. That separation is the whole design."*
- **"How accurate, really?"** → §4. Quote the harness, then the honest ±1–1.5 cm in the wild.
- **"What's the moat?"** → §5.5 + §5.6. The feedback dataset + measured-catalog search; both structurally unavailable to incumbents.
- **"Why won't Vinted just build this?"** → *"They might — and an acqui-hire is a fine outcome. But the wedge is the measured-fit dataset; whoever builds it first owns it. The scraper is for prototyping; the IP is the engine."*

## 10. Business ladder (if asked "what is this, as a company?")
1. **Portfolio / hackathon weapon** (now).
2. **Direct-to-seller micro-SaaS** — £5–15/mo, power-sellers, you own it.
3. **API / SDK to platforms** (Vinted/Depop/Fleek) — the endgame; needs traction first.
4. **Acqui-hire** — an outcome, not a target.
Unlock for all of it: a little real validation + a few real sellers + one number.

## 11. The honesty boundary (keep yourself clean)
- **Live now:** measurement engine, fit, size translation, fit confidence, fit-based search, feedback flywheel, capture guidance, full API + UI.
- **Wired, needs a key:** generative try-on (FASHN / Gemini) — degrades to a labelled placeholder.
- **Framework-ready, needs real data:** the validation MAE is on a synthetic/controlled set; the harness re-runs on real photos by swapping the CSV.
- Say all of this if asked. **Build real, refuse fake** — it's also the most persuasive posture in the room.

---

## 12. Demo-day runbook
**Night before** — laptop tab 1: `deck.html` fullscreen (arrows advance; your cues sit in the strip above the tape bar — unreadable from the judges' distance). Tab 2: `http://127.0.0.1:8000` with the backend running (`uvicorn api.server:app`) and a sample already measured once, so the pipeline is warm. Phone: script + timer. Internet optional — deck and app run fully local.
**Pre-flight (5 min out)** — badge reads *live engine* · *Run a sample* returns the overlay · sliders move the chips · a feedback tap toasts. If the backend dies mid-demo the page degrades to demo data; keep talking, nothing visibly breaks.
**Timing** — 5-min slot → rehearse to **4:30**. **Stop building at T-90.** Two full run-throughs, out loud, timed. Before you're called: in 4, out 6–7, six times.

## 13. Real validation — the 30-minute upgrade
The single highest-value hour left: converts "MAE 0.14 cm (controlled set)" into a real-clothes number nobody can argue with.
1. Print `print/` at **100% / Actual size**; check the 100 mm bar with a ruler.
2. Tape the four corner sheets so the **red outer corners** form **1000 × 1400 mm**; both diagonals ≈ **1720 mm** (equal ⇒ square).
3. Shoot 5–10 garments from above, all four markers in frame.
4. Hand tape-measure each garment; write the numbers into `validation/ground_truth.csv`, photos into `validation/photos/`.
5. `python -m validation.validate` → your real MAE.
6. Put the new number on deck slide 3 and in §4. The asterisk disappears.
